
let targetSidebar = document.querySelector(".navs_container")

function openSidebar(){
    targetSidebar.style.left = "0";
}

function closeSidebar() {
    targetSidebar.style.left = "-100%";
}
